                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2361589
Maxstone Crawler Tank Tracks by evil_k is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Track kit for 1/5 Scale Maxstone Crawler.

Added a second servo to give the crawler four wheel steering and made a short video (poor quality) of the crawler: https://youtu.be/zoORonerMSM


# Print Settings

Printer: multiple printers used
Rafts: No
Supports: Yes
Resolution: .2
Infill: 25

Notes: 
Printed with multiple printers. I printed all parts in PETG. Other material required for each track pod assembly:

2 of 6807-2RS bearings (for drive sprocket)
10 of 625-2RS bearings (two for each idler)
5 of M5 x 65mm bolts (one for each idler)
4 of M5 x 16mm bolts (tension adjustment)
9 of M5 locking (Nylock) nuts (tension adjustment and idlers)
4 of M5 flat washers (tension adjustment)
2 of M3 x 20mm (for shaft clamp)
2 of M3 locking (Nylock) nuts (for shaft clamp)
3mm ABS filament - used to attach the track link segments together

For Anti-rotation of track pod assembly:
4 of M3 x 10mm bolts
4 of M3 locking (Nylock) nuts
4 of M3 flat washers
2 of M5 nuts (used for anti-rotation bracket attachment)
1 of M4 x 14mm bolt (longer bolt for axle steering knuckle Bolt 98073)
1 of 1/8" aluminum plate, 1" x 25mm (bolts to bottom of axle steering knuckle)
2 of 15mm lengths of 1/2" aluminum U channel (bottom spring attachments)
2 of 851631 Hillman Compression Spring (3-1/4" x 13/16", 82.6mm x 20.6mm)
Some 150 pound test down rigger stainless cable
Butt splices used to secure the down rigger cable

For each track pod, will need five idler wheels, one drive sprocket, two side plates, and two idler adjust plates. The 'L' and 'R' in the part names designate for the Left or Right side of the Vehicle. 'O' or "Outside" and "I" or "Inside in the part names designate if the part is on the frame side of the pod (Inside) or away from the frame (Outside.) Will also need two of the shaft lock parts.

Assembly:
If you find the 6807 bearing fits a little loose (all printers are a little different), add a couple wraps of Kapton tape around the mount for the bearing or the bearing, as required.

Mount the bearings in the idler wheels. I used a bolt and nut to pull the bearings in place inside the idler wheels. Mount the bearings in the drive sprocket. Mount the idler adjust plates to the two side plates.

Slide the inside plate over the axle shaft. Mount the nuts into the two shaft clamp parts. Use a piece of Kapton tape to help hold the nuts in place. Hold the two shaft clamp parts on the shaft (axle adapter 59016) while mounting the drive sprocket on to the axle. Ensure the two 3mm bolt holes in the drive sprocket align with the nuts in the shaft clamps. Try to push the shaft clamps into the inside hex hole in the drive sprocket while getting the drive sprocket over the hex shoulder on the axle adapter (easier to do than describe.)

Start the two M3 x 20mm bolts through the two 3mm holes in the drive sprocket (easier to start the bolts before installing the drive sprocket) until the start to engage the nuts in the shaft clamps. Ensure the drive sprocket is fully on the shaft and tighten the two M3 x 20mm bolts. Put the original wheel hub nut on the axle. I put the rough side outwards as do not want it wearing out the PETG plastic. The drive sprocket should now be fairly rigid on the drive axle. Push the inside plate into the bearing on the inside of the drive sprocket.

Should be able to mount the outside plate on the drive sprocket. The five idler wheels can now be attached. Tighten the M5 x 65mm bolts until fairly snug and back off until the idler wheels spin freely (half to one turn of the bolt.)

Track:
With my printer, I required 49 track links per pod. The holes in the track links are two different diameters. The side of the track with three holes has slightly smaller holes - clean these out with a 3mm drill bit. Hold two track links together, interlocked, and push a length of 3mm abs filament through until it comes out the other side. There should be a little bit of a friction fit going through the three holes on the one side of the track link. If your printer prints the holes a little too large, you will need to melt the ends of the abs filament with a soldering iron to flatten out the end so it does not slide through the track links.

Anti-Rotation:
I used what I had available or could easily get. You may have to improvise if you can not get similar parts. You will need four of the Spring Cap parts per pod. Print two of the Guide-60mm parts - these help hold the springs compressed with about 10mm between the insides of the Spring Cap parts while the springs/caps are being secured in place.
Easier to install the spring parts with the tracks removed.

The Maxstone Crawler does not go very fast. Have not noticed any heating of the motors. Turning radius leaves a lot to be desired! Crawler should be upgraded to four wheel steering.

Uploaded a modified version of the track link without the grouser portion. If every second track link does not have a grouser on it, will make it easier to for the track to get a grip to climb over things, though this could be harder on the gears/drive train.